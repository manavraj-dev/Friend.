from __future__ import annotations

import os
from typing import Any


class ClaudeBridge:
    """Thin wrapper around Anthropic. Safe to import without a configured API key."""

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")

    def is_available(self) -> bool:
        return bool(self.api_key)

    def generate(self, *, system_prompt: str, user_message: str, context: str = "") -> str:
        if not self.is_available():
            return self._fallback_reply(user_message, context)

        try:
            import anthropic
        except Exception:
            return self._fallback_reply(user_message, context)

        try:
            client = anthropic.Anthropic(api_key=self.api_key)
            response = client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=512,
                system=system_prompt,
                messages=[{"role": "user", "content": f"{context}\n\n{user_message}"}],
            )
            text = ""
            for block in response.content:
                if getattr(block, "type", None) == "text":
                    text += getattr(block, "text", "")
            return text.strip() or self._fallback_reply(user_message, context)
        except Exception:
            return self._fallback_reply(user_message, context)

    @staticmethod
    def _fallback_reply(user_message: str, context: str = "") -> str:
        message = user_message.strip()
        if not message:
            return "I’m ready to help. What would you like to remember or work through?"
        return (
            "I’ve logged this turn and am keeping the memory flow local-first. "
            f"Current context: {context[:180] or 'general conversation'}. "
            f"Your message was: \"{message[:200]}\""
        )
