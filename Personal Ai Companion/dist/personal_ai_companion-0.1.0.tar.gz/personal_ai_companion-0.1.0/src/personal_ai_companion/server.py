from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel

from .companion import PersonalCompanion


class MessageRequest(BaseModel):
    message: str
    user_name: str = "User"


app = FastAPI(title="Personal AI Companion")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/turn")
def handle_turn(payload: MessageRequest) -> dict[str, Any]:
    companion = PersonalCompanion(vault_root=Path("vault"), user_name=payload.user_name)
    result = companion.process_turn(payload.message)
    return {
        "interpretation": result["interpretation"],
        "action": result["action"],
        "reply": result["reply"],
        "saved_entry": str(result["saved_entry"]),
    }
