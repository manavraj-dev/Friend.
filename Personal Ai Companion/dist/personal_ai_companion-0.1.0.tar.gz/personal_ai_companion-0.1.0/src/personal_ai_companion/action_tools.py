from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass
class SelectActionResult:
    action: str
    based_on_hypotheses: list[str]
    predicted_user_reaction: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SaveMemoryResult:
    save_to: str
    file_path: str
    status: str | None = None
    confidence: float | None = None
    content: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ActionToolRegistry:
    """Schema-ready tool output layer for select_action and save_memory."""

    @staticmethod
    def select_action(action: str, predicted_user_reaction: str, based_on_hypotheses: list[str] | None = None) -> SelectActionResult:
        return SelectActionResult(
            action=action,
            based_on_hypotheses=based_on_hypotheses or [],
            predicted_user_reaction=predicted_user_reaction,
        )

    @staticmethod
    def save_memory(save_to: str, file_path: str, content: str, status: str | None = None, confidence: float | None = None) -> SaveMemoryResult:
        return SaveMemoryResult(
            save_to=save_to,
            file_path=file_path,
            status=status,
            confidence=confidence,
            content=content,
        )
