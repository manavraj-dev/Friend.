from pathlib import Path

from personal_ai_companion.companion import PersonalCompanion
from personal_ai_companion.consolidation import WeeklyConsolidator
from personal_ai_companion.indexer import MemoryIndexer
from personal_ai_companion.interpreter import Interpreter
from personal_ai_companion.vault import VaultManager


def test_interpreter_mode_detects_project_query():
    interpretation = Interpreter.interpret("I need help planning my project deadline and roadmap")
    assert interpretation["mode_suggestion"] == "project"
    assert "planning" in interpretation["needs"]


def test_vault_manager_creates_scaffold(tmp_path):
    manager = VaultManager(tmp_path)
    vault_root = manager.ensure_scaffold()

    assert (vault_root / "daily").exists()
    assert (vault_root / "people").exists()
    assert (vault_root / "core").exists()
    assert (vault_root / "_meta" / "predictions_log.jsonl").exists()


def test_write_and_recall(tmp_path):
    manager = VaultManager(tmp_path)
    manager.ensure_scaffold()
    manager.write_daily_entry("I am working on a book draft and need to remember this later.")

    results = manager.search("book draft")
    assert len(results) >= 1
    assert "book draft".lower() in results[0].chunk_text.lower()


def test_companion_turn_processing(tmp_path):
    companion = PersonalCompanion(vault_root=tmp_path)
    result = companion.process_turn("I need help planning my project deadline and roadmap")

    assert result["interpretation"]["mode_suggestion"] == "project"
    assert result["saved_entry"].exists()
    assert result["prediction"]["action"] in {"ANSWER", "ASK", "ACKNOWLEDGE", "EXPLAIN", "RECALL"}


def test_confide_mode_requires_explicit_user_signal():
    from personal_ai_companion.interpreter import Interpreter
    interpretation = Interpreter.interpret("I feel really anxious and need to tell you something personal")

    assert interpretation["mode_suggestion"] in {"checkin", "mixed"}
    assert interpretation["mode_requires_confirmation"] is True


def test_companion_fallback_reply_is_generated(tmp_path):
    companion = PersonalCompanion(vault_root=tmp_path)
    result = companion.process_turn("I want to remember what I said about my sister last month")

    assert "reply" in result
    assert isinstance(result["reply"], str)
    assert len(result["reply"]) > 0


def test_memory_indexer_parses_person_hypotheses(tmp_path):
    vault = tmp_path / "vault"
    people = vault / "people"
    people.mkdir(parents=True)
    (people / "sarah.md").write_text(
        "---\nid: \"sarah\"\ntype: person\nsensitivity: normal\nsource: user\n---\n\n"
        "## Communication Style\n"
        "<!-- meta: {\"status\": \"fact\", \"confidence\": 1.0} -->\n"
        "Prefers conceptual explanations.\n\n"
        "## Hypothesis: prefers brevity under urgency\n"
        "<!-- meta: {\"status\": \"hypothesis\", \"confidence\": 0.71, \"evidence_count\": 4} -->\n"
        "She prefers shorter answers when rushed.\n",
        encoding="utf-8",
    )

    indexer = MemoryIndexer(vault_root=vault)
    rows = indexer.index_vault()

    assert len(rows) >= 2
    statuses = {row["status"] for row in rows}
    assert "fact" in statuses
    assert "hypothesis" in statuses


def test_weekly_consolidator_updates_hypothesis_confidence(tmp_path):
    vault = tmp_path / "vault"
    people = vault / "people"
    people.mkdir(parents=True)
    (people / "sarah.md").write_text(
        "---\nid: \"sarah\"\ntype: person\nsensitivity: normal\nsource: user\n---\n\n"
        "## Hypothesis: prefers brevity under urgency\n"
        "<!-- meta: {\"status\": \"hypothesis\", \"confidence\": 0.71, \"evidence_count\": 4} -->\n"
        "She prefers shorter answers when rushed.\n",
        encoding="utf-8",
    )
    (vault / "_meta").mkdir(exist_ok=True)
    (vault / "_meta" / "predictions_log.jsonl").write_text(
        '{"action": "ANSWER", "predicted_user_reaction": "continue", "based_on_hypotheses": ["Hypothesis: prefers brevity under urgency"]}\n'
        '{"action": "ANSWER", "predicted_user_reaction": "continue", "based_on_hypotheses": ["Hypothesis: prefers brevity under urgency"]}\n',
        encoding="utf-8",
    )

    consolidator = WeeklyConsolidator(vault_root=vault)
    changed = consolidator.consolidate_week()

    assert any("hypothesis" in entry.lower() for entry in changed)
